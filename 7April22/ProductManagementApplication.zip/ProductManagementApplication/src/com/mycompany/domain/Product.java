package com.mycompany.domain;

public class Product {
	String Product_ID ;
	String Product_Name ;
	double Product_Price ;
	
	//constructor
	public Product(String p_id, String p_name, double price) {
		super();
		this.Product_ID  = p_id;
		this.Product_Name  = p_name;
		this.Product_Price  = price;
	}
	//getter setters
	public String getProduct_id() {
		return Product_ID;
	}
	public void setProduct_id(String id) {
		this.Product_ID = id;
	}
	public String getProduct_name() {
		return Product_Name;
	}
	public void setProduct_name(String product_name) {
		this.Product_Name = product_name;
	}
	public double getProduct_price() {
		return Product_Price;
	}
	public void setProduct_price(double price) {
		this.Product_Price = price;
	}
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Product ID=" + Product_ID + ",Product Name=" + Product_Name + ", Product Price=" + Product_Price;
	}
}
