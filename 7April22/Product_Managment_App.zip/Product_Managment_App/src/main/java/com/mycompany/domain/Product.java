package com.mycompany.domain;

public class Product {
	String Product_ID;
	String Product_Name;
	int Product_price;
	
	
	public Product(String p_id, String p_name, int p_price) {
		super();
		this.Product_ID = p_id;;
		this.Product_Name = p_name;;
		this.Product_price = p_price;;
	}


	public String getProduct_ID() {
		return Product_ID;
	}


	public void setProduct_ID(String product_ID) {
		Product_ID = product_ID;
	}


	public String getProduct_Name() {
		return Product_Name;
	}


	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}


	public int getProduct_price() {
		return Product_price;
	}


	public void setProduct_price(int product_price) {
		Product_price = product_price;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Product [Product_ID=" + Product_ID + ", Product_Name=" + Product_Name + ", Product_price="
				+ Product_price + "]";
	}

	
}