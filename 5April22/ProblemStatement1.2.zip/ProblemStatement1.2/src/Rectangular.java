import java.util.Scanner;

public class Rectangular {
	int length;
	int breadth;
	int area;
	
	public Rectangular() {
		length = 0;
		breadth = 0;
	}
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length value : ");
		length = sc.nextInt();
		System.out.println();
		breadth=sc.nextInt();
	}
	void cal() {
		area=length*breadth;
		
	}
	void display() {
		System.out.println("Area of Reactangle = "+area);
	}
	
	 public static void main(String args[]) {
		 	Rectangular obj1 = new Rectangular();
	        obj1.input();
	        obj1.cal();
	        obj1.display();
	        System.out.println("****************************");
	        Rectangular obj2 = new Rectangular();
	        obj2.input();
	        obj2.cal();
	        obj2.display();
	        System.out.println("****************************");
	        Rectangular obj3 = new Rectangular();
	        obj3.input();
	        obj3.cal();
	        obj3.display();
	        System.out.println("****************************");
	        Rectangular obj4 = new Rectangular();
	        obj4.input();
	        obj4.cal();
	        obj4.display();
	        System.out.println("****************************");
	        Rectangular obj5 = new Rectangular();
	        obj5.input();
	        obj5.cal();
	        obj5.display();
	    }

}
