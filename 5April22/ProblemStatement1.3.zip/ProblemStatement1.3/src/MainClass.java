
public class MainClass {
	public void CreateBooks() {
		Book b[] = new Book[2];
		b[0] = new Book("Java Programming",350.50);
		b[1] = new Book("Let Us C",200.00);
		for(int i=0; i<b.length; i++)
		{
			b[i].display();
			System.out.println(" ");
		}
	}
	public void ShowBooks() {
		CreateBooks();
	}
	public static void main(String args[] ){
		MainClass m1=new MainClass();
		m1.ShowBooks();
		
	}

}
