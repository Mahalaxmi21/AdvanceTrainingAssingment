import java.util.Scanner;

public class Rectangle_Modify {
	int  length;
	int width;
	int area;
	int parameter;
	
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	
	public Rectangle_Modify() {
		length = 1;
		width = 1;
	}
	void input() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of reactangle: ");
		length = sc.nextInt();
		System.out.println("Enter width of reactangle: ");
		width = sc.nextInt();
	}
	void areaOfRectangle() {
		area = length*width;
	}
	void parameterRectangle() {
		parameter = 2*(length+width);
		
	}
	void display() {
		if(length>0 && length<20) {
			System.out.println("Area of Rectangle = " + area);
	        System.out.println("Parameter of Rectangle = " +parameter);}
	       	
		}
	public static void main(String args[]) {
		Rectangle_Modify obj1 = new Rectangle_Modify();
		obj1.input();
        obj1.areaOfRectangle();
        obj1.parameterRectangle();
        obj1.display();
        System.out.println("****************************");
        Rectangle_Modify obj2 = new Rectangle_Modify();
		obj2.input();
        obj2.areaOfRectangle();
        obj2.parameterRectangle();
        obj2.display();
        System.out.println("****************************");
        Rectangle_Modify obj3 = new Rectangle_Modify();
		obj3.input();
        obj3.areaOfRectangle();
        obj3.parameterRectangle();
        obj3.display();
        System.out.println("****************************");
        Rectangle_Modify obj4 = new Rectangle_Modify();
		obj4.input();
        obj4.areaOfRectangle();
        obj4.parameterRectangle();
        obj4.display();
        System.out.println("****************************");
        Rectangle_Modify obj5 = new Rectangle_Modify();
		obj5.input();
        obj5.areaOfRectangle();
        obj5.parameterRectangle();
        obj5.display();
        
	}
	

}
